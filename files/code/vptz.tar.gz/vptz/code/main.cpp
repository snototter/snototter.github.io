/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#include <iostream>
#include <cstdlib>
#include <string>
#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

#include "virtualptz.h"
#include "utils.h"
#include "imagesource.h"
#include "imagesourcevideo.h"

using vptz::VirtualPtz;
using vptz::ImageSource;
using vptz::ImageSourceVideo;
using vptz::Utils;

/** @brief Title of the main window. */
#define WINDOW_NAME "Virtual PTZ"

/** @brief Supported operation modes. */
typedef enum {
  SampleTrajectory, /**< Application shows a sample trajectory. */
  Interactive       /**< Application reacts to user interaction. */
} DemoMode;

/** @brief Application configuration. */
typedef struct {
  DemoMode mode;               /**< Operation mode. */
  int pinhole_width;           /**< Horizontal resolution of the virtual pinhole. */
  int pinhole_height;          /**< Vertical resolution of the virtual pinhole. */
  double pinhole_focal_length; /**< Focal length of the virtual pinhole. */
  std::string panoramic_video; /**< Path to the panoramic video file. */
} DemoConfig;


/** @brief Callback handler for user interaction. */
void mouse_callback(int event, int x, int y, int flags, void* user_data);

/** @brief Displays the program's help/info screen upon console. */
void display_usage();

/** @brief Parses the command line arguments. */
bool parse_arguments(int argc, char **argv, DemoConfig *config);



/** @brief Main entry point to the vPTZ sample application. */
int main(int argc, char **argv)
{
  // Parse command line
  DemoConfig cfg;
  if (!parse_arguments(argc, argv, &cfg))
  {
    display_usage();
    return -1;
  }

  // Try to access panoramic imagery
  ImageSource *image_source = new ImageSourceVideo(cfg.panoramic_video);
  if (!image_source->isOpened())
  {
    std::cerr << "[Error] Could not access panoramic imagery - aborting" << std::endl;
    delete image_source;
    return -2;
  }

  // Set up virtual PTZ
  VirtualPtz ptz(image_source);
  ptz.setResolution(cfg.pinhole_width, cfg.pinhole_height);
  ptz.setFocalLength(cfg.pinhole_focal_length);

  // Open window
  cv::namedWindow(WINDOW_NAME);

  if (cfg.mode == Interactive)
  {
    // Operation mode: interaction

    // Set up callback handler
    cv::setMouseCallback(WINDOW_NAME, mouse_callback, &ptz);

    // Display current vPTZ frame
    cv::Mat img;
    ptz.currentFrame(img);
    cv::imshow(WINDOW_NAME, img);

    // Wait until window gets closed or user hits ESC
    int key = 1;
    while ((char)key != 27 && key > 0)
      key = cv::waitKey();
  }
  else
  {
    // Operation mode: sample trajectory

    // The following code causes the vPTZ to pan from left to right.
    // The total pan distance is divided into several sections. Within
    // each section, the camera will tilt between +/-10 degrees.

    int sections = 3;
    int steps_per_section = 50;
    cv::Mat img;
    int key = 0;
    bool running = true;

    for (int section = 0; running && section < sections; ++section)
    {
      // Compute pan/tilt limits for the current section
      double pan_from = -45.0 + section * (90.0/(double)sections);
      double pan_to = pan_from + (90.0/(double)sections);
      double tilt_from = (section % 2 ? -1 : +1) * 10.0;
      double tilt_to = -tilt_from;

      // A section lasts for steps_per_section steps
      for (int step = 0; running && step < steps_per_section; ++step)
      {
        // Compute desired pan/tilt angles
        double p = pan_from + step*(pan_to - pan_from)/(double)steps_per_section;
        double t = tilt_from + step*(tilt_to - tilt_from)/(double)steps_per_section;

        // Adjust vPTZ camera
        ptz.panAbsolute(Utils::radian(p));
        ptz.tiltAbsolute(Utils::radian(t));

        // Update display
        ptz.currentFrame(img);
        cv::imshow(WINDOW_NAME, img);
        key = cv::waitKey(10);

        // Load next panorama frame
        ptz.nextFrame();

        // Check for premature exit
        running = (char)key != 27;
      }
    }
  }

  return 0;
}



void mouse_callback(int event, int x, int y, int /*flags*/, void* user_data)
{
  VirtualPtz *ptz = (VirtualPtz*)user_data;
  cv::Mat img;

  switch(event)
  {
  case CV_EVENT_LBUTTONDOWN:
    // Adjust the vPTZ camera and display the new pinhole view
    ptz->centerOn(x, y);
    ptz->currentFrame(img);
    cv::imshow(WINDOW_NAME, img);
    break;

  case CV_EVENT_RBUTTONDOWN:
    // Try to advance to next frame of the panorama sequence
    if (ptz->nextFrame())
    {
      ptz->currentFrame(img);
      cv::imshow(WINDOW_NAME, img);
    }
    else
    {
      std::cout << "[Information] Cannot load next frame." << std::endl;
    }
    break;

  default:
    break;
  }
}


void display_usage()
{
  std::cout << std::endl
      << "Usage: " << std::endl << std::endl
      << "  vptz [options] -p <path-to-panoramic-video>" << std::endl << std::endl
      << "where valid options include:" << std::endl << std::endl
      << "  Operation mode:" << std::endl
      << "    Specifies whether the application demonstrates a sample trajectory," << std::endl
      << "    or it reacts to user interaction. Note: these operation mode " << std::endl
      << "    switches are exclusive, i.e. you can only specify one. Default" << std::endl
      << "    operation mode is interactive (-i)." << std::endl << std::endl
      << "    -s" << std::endl
      << "      Sample trajectory mode - the application performs a sample" << std::endl
      << "      trajectory of the virtual PTZ camera and terminates." << std::endl
      << "      You may exit the application prematurely by pressing ESC." << std::endl
      << std::endl
      << "    -i" << std::endl
      << "      Interactive mode - left click centers the virtual PTZ camera" << std::endl
      << "      at the specified position. Right click loads the next panorama" << std::endl
      << "      frame." << std::endl
      << "      You max exit the application by closing the pinhole window or " << std::endl
      << "      pressing ESC." << std::endl
      << std::endl
      << "  Pinhole configuration:" << std::endl
      << std::endl
      << "    -f <focal-length>" << std::endl
      << "      Sets the focal length of the virtual pinhole to the" << std::endl
      << "      double precision value focal-length (in pixels)." << std::endl
      << "      Defaults to a focal length of 900 pixels." << std::endl
      << std::endl
      << "    -r <width> <height>" << std::endl
      << "      Sets the resolution of the virtual pinhole view to the" << std::endl
      << "      integral values width and height (in pixels). Defaults" << std::endl
      << "      to a width of 800 and a height of 600 pixels." << std::endl
      << std::endl
      << "Sample calls:" << std::endl
      << "  vptz -p /path/to/panorama.avi" << std::endl
      << "    Starts the application in interactive mode with the" << std::endl
      << "    specified panorama video." << std::endl
      << std::endl
      << "  vptz -s -r 640 480 -f 400 -p /path/to/panorama.avi" << std::endl
      << "    The application will demonstrate a sample trajectory" << std::endl
      << "    on the specified panorama video using a pinhole resolution" << std::endl
      << "    of 640x480 and a focal length of 400." << std::endl
      << std::endl;
}


bool parse_arguments(int argc, char**argv, DemoConfig *config)
{
  // Default configuration
  config->mode = Interactive;
  config->pinhole_width = 800;
  config->pinhole_height = 600;
  config->pinhole_focal_length = 900;
  config->panoramic_video = "";

  // Parse command line arguments
  bool valid_opts = true;
  bool video_specified = false;
  bool mode_specified = false;
  int idx = 1;
  while (idx < argc)
  {
    std::string arg(argv[idx]);

    if (!arg.compare("-s"))
    {
      // Sample trajectory mode
      if (!mode_specified)
      {
        mode_specified = true;
        config->mode = SampleTrajectory;
      }
      else
      {
        valid_opts = false;
        std::cerr << "[Error] Multiple operation modes specified" << std::endl;
      }
    }
    else if (!arg.compare("-i"))
    {
      // Interactive mode
      if (!mode_specified)
      {
        mode_specified = true;
        config->mode = Interactive;
      }
      else
      {
        valid_opts = false;
        std::cerr << "[Error] Multiple operation modes specified" << std::endl;
      }
    }
    else if (!arg.compare("-f"))
    {
      // Focal length parameter
      if (idx + 1 < argc)
      {
        config->pinhole_focal_length = atof(argv[idx+1]);
        ++idx;
      }
      else
      {
        valid_opts = false;
        std::cerr << "[Error] Invalid focal length parameter" << std::endl;
      }
    }
    else if (!arg.compare("-r"))
    {
      // Pinhole resolution
      if (idx + 2 < argc)
      {
        config->pinhole_width = atoi(argv[idx+1]);
        config->pinhole_height = atoi(argv[idx+2]);
        idx += 2;
      }
      else
      {
        valid_opts = false;
        std::cerr << "[Error] Invalid pinhole resolution argument" << std::endl;
      }
    }
    else if (!arg.compare("-p"))
    {
      // Path to video file
      if (idx + 1 < argc)
      {
        video_specified = true;
        config->panoramic_video = argv[idx+1];
        ++idx;
      }
      else
      {
        valid_opts = false;
        std::cerr << "[Error] Invalid video file argument" << std::endl;
      }
    }
    else
    {
      std::cerr << "[Error] Invalid argument '" << arg << "'" << std::endl;
      valid_opts = false;
    }

    ++idx;
  }
  return valid_opts && video_specified;
}
