/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#include "virtualptz.h"

#include <opencv2/highgui/highgui.hpp>
#include <math.h>

#include "imagesource.h"
#include "utils.h"

namespace vptz {

  VirtualPtz::VirtualPtz(ImageSource *image_source) : image_source_(image_source),
      pan_(0), tilt_(0), focal_length_(400), pinhole_width_(800), pinhole_height_(600),
      panorama_width_(5400), panorama_height_(2700), angle_scale_(0.69875)
  {
    assert(image_source != NULL
        && image_source->imageSize().width == 5400
        && image_source->imageSize().height == 2700);
  }

  VirtualPtz::~VirtualPtz()
  {
    if (image_source_)
    {
      delete image_source_;
      image_source_ = 0;
    }
  }

  void VirtualPtz::currentFrame(cv::Mat &img)
  {
    cv::Mat pano = image_source_->currentFrame();
    assert(pano.type() == CV_8UC3);

    img.create(pinhole_height_, pinhole_width_, pano.type());
    img.setTo(cv::Scalar::all(0));

    // Precompute rotation matrix (negative tilt angle because
    // of flipped vertical image axis)
    cv::Mat R;
    Utils::rotationMatrix(-tilt_, pan_, 0, R);

  #pragma omp parallel for
    for (int process = 0; process < pinhole_height_*pinhole_width_; ++process)
    {
      int row = process / pinhole_width_;
      int col = process % pinhole_width_;

      // Compute ray from optical center to pixel position
      double y = -(pinhole_height_-1)/2.0 + (double)row;
      double x = -(pinhole_width_-1)/2.0 + (double)col;
      cv::Point3d ray(x, y, focal_length_);

      // Account for pan/tilt angles
      cv::Mat rayMat(ray);
      rayMat = R * rayMat;
      ray = rayMat.at<cv::Point3d>(0,0);

      // Compute corresponding pixel at panorama
      cv::Point2d pixel = projectToPixel(ray);
      int px = (int)pixel.x;
      int py = (int)pixel.y;

      if (px >= 0 && px < panorama_width_
       && py >= 0 && py < panorama_height_)
        img.at<cv::Vec3b>(row, col) = pano.at<cv::Vec3b>(py, px);
    }
  }

  bool VirtualPtz::nextFrame()
  {
    return image_source_->next();
  }

  void VirtualPtz::panAbsolute(double p)
  {
    pan_ = p;
  }

  void VirtualPtz::panRelative(double p)
  {
    pan_ += p;
  }

  void VirtualPtz::tiltAbsolute(double t)
  {
    tilt_ = t;

    if (tilt_ > CV_PI/2.0)
      tilt_ = CV_PI/2.0;
    if (tilt_ < -CV_PI/2.0)
      tilt_ = -CV_PI/2.0;
  }


  void VirtualPtz::tiltRelative(double t)
  {
    tilt_ += t;

    if (tilt_ > CV_PI/2.0)
      tilt_ = CV_PI/2.0;
    if (tilt_ < -CV_PI/2.0)
      tilt_ = -CV_PI/2.0;
  }

  void VirtualPtz::setFocalLength(double f)
  {
    assert(f > 0);

    focal_length_ = f;
  }

  void VirtualPtz::setResolution(int width, int height)
  {
    assert(width > 0 && height > 0);

    pinhole_width_ = width;
    pinhole_height_ = height;
  }

  void VirtualPtz::centerOn(double x, double y)
  {
    // Principal point is at pinhole center
    double x_translated = x - ((double)pinhole_width_/2.0);
    double y_translated = y - ((double)pinhole_height_/2.0);

    // Compute desired pan/tilt angles
    double lambda = atan(x_translated/focal_length_);
    double phi = atan(y_translated/focal_length_);

    // Pan/tilt relative to current position
    panRelative(lambda);
    tiltRelative(phi);
  }

  double VirtualPtz::panAngle()
  {
    return pan_;
  }

  double VirtualPtz::tiltAngle()
  {
    return tilt_;
  }

  double VirtualPtz::focalLength()
  {
    return focal_length_;
  }

  inline cv::Point2d VirtualPtz::projectToPixel(const cv::Point3d &X) const
  {
    double norm_factor = sqrt(X.x *X.x + X.z*X.z);
    cv::Point3d Xc(X.x/norm_factor, X.y/norm_factor, X.z/norm_factor);

    double half_height = ((double)panorama_height_) / 2.;
    double c = (2. * CV_PI) / panorama_width_;

    double sinl = Xc.x;
    double cosl = Xc.z;
    double l = acos(cosl);

    if (sinl < 0)
      l =  2. * CV_PI - l;

    l = l / (2. * CV_PI) * 360.;

    l = l - 180.;

    if (l < 0)
      l = 360. + l;

    double x = l * (2. * CV_PI) / (360. * c);
    double y = Xc.y * (half_height * angle_scale_) + half_height;

    cv::Point2d p(x, y);
    return p;
  }

} // end namespace
