/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#ifndef __UTILS_H__
#define __UTILS_H__

#include <opencv2/imgproc/imgproc.hpp>

namespace vptz {
  /**
   * @brief Collection of auxiliary methods for the VirtualPtz project.
   */
  class Utils
  {
  public:
    /**
     * @brief Computes the 3D rotation matrix using the provided rotation angles (given in radians).
     *
     * @param omega - radians: rotation around x-axis.
     * @param phi - radians: rotation around y-axis.
     * @param kappa - radians: rotation around z-axis.
     * @param R - the resultant 3x3 rotation matrix (type CV_64FC1).
     */
    static inline void rotationMatrix(double omega, double phi, double kappa, cv::Mat &R)
    {
      cv::Vec3d angles(omega, phi, kappa);
      rotationMatrix(angles, R);
    }

    /**
     * @brief Computes the 3D rotation matrix using the provided rotation angles (given in radians).
     *
     * @param angles - rotation angles in radians, s.t. angles[0] = rotation around x-axis,
     *   angles[1] = rotation around y-axis, angles[2] = rotation around z-axis.
     * @param R - the resultant 3x3 rotation matrix (type CV_64FC1).
     */
    static inline void rotationMatrix(const cv::Vec3d &angles, cv::Mat &R)
    {
      double so = sin(angles.val[0]);
      double sp = sin(angles.val[1]);
      double sk = sin(angles.val[2]);
      double co = cos(angles.val[0]);
      double cp = cos(angles.val[1]);
      double ck = cos(angles.val[2]);

      R.create(3, 3, CV_64FC1);
      R.at<double>(0, 0) = cp*ck;
      R.at<double>(1, 0) = cp*sk;
      R.at<double>(2, 0) = -sp;
      R.at<double>(0, 1) = so*sp*ck-co*sk;
      R.at<double>(1, 1) = so*sp*sk+co*ck;
      R.at<double>(2, 1) = so*cp;
      R.at<double>(0, 2) = co*sp*ck+so*sk;
      R.at<double>(1, 2) = co*sp*sk-so*ck;
      R.at<double>(2, 2) = co*cp;
    }

    /**
     * @brief Convert angle from degree to radian.
     *
     * @param deg - angle in degrees.
     * @return double - angle in radians.
     */
    static inline double radian(double deg)
    {
      return (CV_PI / 180.0 * deg);
    }

    /**
     * @brief Convert angle from radian to degree.
     *
     * @param rad - angle in radians.
     * @return double - angle in degrees.
     */
    static inline double degree(double rad)
    {
      return (180.0 / CV_PI  * rad);
    }

  private:
    /**
     * @brief Private constructor to prevent instantiation.
     */
    Utils();
  };
} // end namespace

#endif // __UTILS_H__
