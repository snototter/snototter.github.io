/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#ifndef __VIRTUAL_PTZ_H__
#define __VIRTUAL_PTZ_H__

#include <opencv2/imgproc/imgproc.hpp>

namespace vptz {
  class ImageSource;

  /**
   * @brief Simulation of real PTZ functionality using panoramic imagery of a scene.
   */
  class VirtualPtz
  {
  public:
    /**
     * @brief Constructor.
     *
     * @param image_source - provider of panoramic imagery, memory will be erased upon class destructor.
     */
    VirtualPtz(ImageSource *image_source);

    /**
     * @brief Destructor.
     */
    ~VirtualPtz();

    /**
     * @brief Computes the virtual pinhole view for the current panorama.
     *
     * @param img - contains the virtual pinhole view after execution.
     */
    void currentFrame(cv::Mat &img);

    /**
     * @brief Jumps to the next frame of the underlying panoramic image source.
     *
     * @return bool - true upon success, false if an error occured or no more frames are available.
     */
    bool nextFrame();

    /**
     * @brief Sets the given pan angle.
     *
     * @param p - pan angle in radians.
     */
    void panAbsolute(double p);

    /**
     * @brief Causes a pan by p radians relative to the current pan position.
     *
     * @param p - pan angle in radians.
     */
    void panRelative(double p);

    /**
     * @brief Sets the given tilt angle.
     *
     * @param t - tilt angle in radians.
     */
    void tiltAbsolute(double t);

    /**
     * @brief Causes a tilt by t radians relative to the current tilt position.
     *
     * @param t - tilt angle in radians.
     */
    void tiltRelative(double t);

    /**
     * @brief Sets the focal length of the virtual pinhole.
     *
     * @param f - focal length.
     */
    void setFocalLength(double f);

    /**
     * @brief Sets the resolution of the virtual pinhole.
     *
     * @param width - width of the pinhole view.
     * @param height - height of the pinhole view.
     */
    void setResolution(int width, int height);

    /**
     * @brief Centers the virtual pinhole on the given pixel location.
     *
     * @param x - x-coordinate of the pixel at the pinhole view to center on.
     * @param y - y-coordinate of the pixel at the pinhole view to center on.
     */
    void centerOn(double x, double y);

    /**
     * @brief Returns the current pan angle.
     *
     * @return double - current pan angle in radians.
     */
    double panAngle();

    /**
     * @brief Returns the current tilt angle.
     *
     * @return double - current tilt angle in radians.
     */
    double tiltAngle();

    /**
     * @brief Returns the current focal length of the virtual pinhole.
     *
     * @return double - current focal length.
     */
    double focalLength();


  private:
    ImageSource *image_source_; /**< Provides the required panoramic imagery. */

    double pan_;                /**< Pan angle of the vPTZ camera (positive angles cause clockwise panning). */
    double tilt_;               /**< Tilt angle of the vPTZ camera. */
    double focal_length_;       /**< Focal length of the virtual pinhole view. */

    int pinhole_width_;         /**< Width of the virtual pinhole view. */
    int pinhole_height_;        /**< Height of the virtual pinhole view. */

    int panorama_width_;        /**< Width of a panorama. */
    int panorama_height_;       /**< Height of a panorama. */
    double angle_scale_;        /**< Scaling factor for panorama projection. */

    /**
     * @brief Computes the 2D panorama pixel position for a 3D ray.
     *
     * @param X - ray from projection center/optical center to a 3D point.
     * @return cv::Point2d - position on the panorama image (i.e. the intersection point between 3D ray and cylinder).
     */
    cv::Point2d projectToPixel(const cv::Point3d &X) const;
  };

} // end namespace

#endif // __VIRTUAL_PTZ_H__
