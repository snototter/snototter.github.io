/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#ifndef __IMAGESOURCE_H__
#define __IMAGESOURCE_H__

#include <opencv2/imgproc/imgproc.hpp>

namespace vptz {
  /**
   * @brief Base class for image sources.
   */
  class ImageSource
  {
  public:
    /**
     * @brief C'tor.
     */
    ImageSource() {}

    /**
     * @brief Destructor.
     */
    virtual ~ImageSource() {}

    /**
     * @brief Returns the current frame.
     *
     * @return cv::Mat - the current frame.
     */
    cv::Mat currentFrame()
    {
      return current_image_;
    }

    /**
     * @brief Indicates whether the image source is available.
     *
     * @return bool - true if imagery can be queried, false otherwise.
     */
    virtual bool isOpened() = 0;

    /**
     * @brief Advances to the next frame.
     *
     * @return bool - true upon success, false if an error occured or no more frames are left.
     */
    virtual bool next() = 0;

    /**
     * @brief Returns the number of total frames.
     *
     * @return int - positive number for finite frames, negative for live streams or if frame count could not be obtained.
     */
    virtual int totalFrames() = 0;

    /**
     * @brief Returns the frame size.
     *
     * @return cv::Size - the frame size.
     */
    virtual cv::Size imageSize() = 0;

  protected:
    cv::Mat current_image_; /**< Holds the current frame. */
  };

} // end namespace

#endif // IMAGESOURCE_H
