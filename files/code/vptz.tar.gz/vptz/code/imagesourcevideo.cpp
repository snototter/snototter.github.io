/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#include "imagesourcevideo.h"

#include <iostream>

namespace vptz {

  ImageSourceVideo::ImageSourceVideo(const std::string &video_file) : ImageSource(), capture_(0)
  {
    loadVideoFile(video_file);
  }

  ImageSourceVideo::~ImageSourceVideo()
  {
    if (capture_)
    {
      delete capture_;
      capture_ = 0;
    }
  }

  bool ImageSourceVideo::loadVideoFile(const std::string &video_file)
  {
    if (!capture_)
      capture_ = new cv::VideoCapture();

    capture_->open(video_file);
    if (!capture_->isOpened())
    {
      std::cerr << "[Error] Cannot open video file '" << video_file << "'" << std::endl;
      return false;
    }

    // Load first frame
    return next();
  }

  bool ImageSourceVideo::isOpened()
  {
    return capture_ && capture_->isOpened();
  }

  bool ImageSourceVideo::next()
  {
    // Grab the next frame
    if (capture_ && capture_->grab())
      return capture_->retrieve(current_image_);
    return false;
  }

  int ImageSourceVideo::totalFrames()
  {
    // Query total number of frames
    if (capture_ && capture_->isOpened())
      return (int)capture_->get(CV_CAP_PROP_FRAME_COUNT);
    return -1;
  }

  cv::Size ImageSourceVideo::imageSize()
  {
    // Query frame width/height
    int w = (int)capture_->get(CV_CAP_PROP_FRAME_WIDTH);
    int h = (int)capture_->get(CV_CAP_PROP_FRAME_HEIGHT);
    return cv::Size(w, h);
  }

} // end namespace
