/**
 * Copyright (c) ICG. All rights reserved.
 *
 * Institute for Computer Graphics and Vision
 * Graz, University of Technology / Austria
 *
 *
 * This software is distributed WITHOUT ANY WARRANTY; without even
 * the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
 * PURPOSE.  See the included copyright notices for more information.
 *
 *
 * Author : Horst Possegger
 * EMail  : possegger@icg.tugraz.at
 * Date   : Dec/28/2011
 */

#ifndef __IMAGESOURCE_VIDEO_H__
#define __IMAGESOURCE_VIDEO_H__

#include "imagesource.h"

#include <opencv2/imgproc/imgproc.hpp>
#include <opencv2/highgui/highgui.hpp>

namespace vptz {
  /**
   * @brief Image source handling video files.
   */
  class ImageSourceVideo : public ImageSource
  {
  public:
      /**
       * @brief C'tor loading the given video file.
       *
       * @param video_file - file name of the video file.
       */
      ImageSourceVideo(const std::string &video_file);

      /**
       * @brief Destructor.
       */
      virtual ~ImageSourceVideo();

      /**
       * @brief Indicates whether the image source is available.
       *
       * @return bool - true if imagery can be queried, false otherwise.
       */
      virtual bool isOpened();

      /**
       * @brief Advances to the next frame.
       *
       * @return bool - true upon success, false if an error occured or no more frames are left.
       */
      virtual bool next();

      /**
       * @brief Returns the number of total frames.
       *
       * @return int - positive number for finite frames, negative for live streams or if frame count could not be obtained.
       */
      virtual int totalFrames();

      /**
       * @brief Returns the frame size.
       *
       * @return cv::Size - the frame size.
       */
      virtual cv::Size imageSize();


  private:
      cv::VideoCapture *capture_; /**< Video capture to access the file. */

      /**
       * @brief Loads the given video file.
       *
       * @param video_file - file name of the video file
       * @return bool - true if file could be loaded, false otherwise
       */
      bool loadVideoFile(const std::string &video_file);
  };
} // end namespace

#endif // __IMAGESOURCE_VIDEO_H__
